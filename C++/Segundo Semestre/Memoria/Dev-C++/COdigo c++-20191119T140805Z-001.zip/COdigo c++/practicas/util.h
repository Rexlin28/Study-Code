#ifndef _UTIL_H_
#define _UTIL_H_
void gotoxy(int x, int y);
void clrscr();

#endif
