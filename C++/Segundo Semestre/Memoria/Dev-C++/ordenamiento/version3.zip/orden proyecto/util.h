void ordenar(int vecto[], int canti);
void mostrar(char * mensa, int * lista, int n);
void intercambio (int *x, int *y);
