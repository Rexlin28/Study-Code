#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "util.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	#include <stdio.h>
#include <conio.h>
#include "util.h"
// 	int*vecto


	 //Entradas
	int cantidad; //cantidad de numeros
	int numero[100];
	int i;
	printf("increse el numero de valores a evaluar: ");
	scanf("%d", &cantidad);
	
	for(i=0; i<cantidad; i++){
		printf("Dame el numero %d: ", (i+1));
		scanf("%d", &numero[i]);	
	}
	printf("Los numeros introducidos son : \n");
		for(i=0; i<cantidad; i++){
		printf("%d ",numero[i]);	
		}
		ordenar(numero, i);
		mostrar("los numeros introducidos son: \n", numero, cantidad);

	return 0;
}
