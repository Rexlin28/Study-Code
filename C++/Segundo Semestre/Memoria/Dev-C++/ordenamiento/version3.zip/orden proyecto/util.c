#include "util.h"

void ordenar(int vecto[], int canti){
	int i, j, auxi;
	for(i=0; i<canti;i++)
	
		for(j=i+1; j<canti; j++)
		
			if (vecto[i]  > vecto[j]){
			intercambio(&vecto[i], &vecto[j]);
			}
	
}

void intercambio (int *x, int *y){
	int auxi;
	auxi=*x;
	*x=*y;
	*y=auxi;
}

void mostrar(char * mensa, int * lista, int cantidad){
	printf("los numeros ordenados son: ");
	int i;
	for (i=0; i<cantidad; i++){
		printf("%d ", lista[i]);
		
	}
	
}
