#ifndef _FIGURAS_H_
#define _FIGURAS_H_

char *repetir(char * cade, int canti);
void rectangulo (int altura, int ancho);
void triangulo(int altura);
void hexagono(int lado);

#endif /* _FIGURAS_H_*/
