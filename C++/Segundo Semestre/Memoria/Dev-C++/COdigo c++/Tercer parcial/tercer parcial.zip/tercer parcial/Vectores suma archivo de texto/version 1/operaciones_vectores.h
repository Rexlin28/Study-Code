#ifndef _operaciones_vectores_
#define _operadores_vectores_

void suma_lineas(char *nomb_archi);

#endif //_operaciones_vectores_
