#ifndef _ESTADISTICA_H_
#define _ESTADISTICA_H_

int mayor(int vecto[], int n);
int dameIntervalo(char *mensa, int infe, int supe);
void capturarVector(int vecto[], int n);
int menor(int vecto[], int n);
float media(int vecto[], int n);

#endif /* _ESTADISTICA_H_ */
