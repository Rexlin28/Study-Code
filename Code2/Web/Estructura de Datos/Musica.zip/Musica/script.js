var canciones = ["The Unforgiven", "Shine on you Crazy Diamond", "Fear of The Night", "The Ballad of The Bull", "Killer Queen"];
var reproductor = "";
var historial = [];


function RestartQueue(){ // Reinicia y vuelve a imprimir las Queue de las canciones
    var algo = document.getElementById("queue");
    var cosa;
    algo.innerHTML= "";
    for(let i=0; i<canciones.length; i++){
        cosa = document.createElement("li");
        cosa.innerHTML = canciones[i] + "<button onclick='Eliminar("+i+")' id='song#"+i+"'>Borrar</button>";
        algo.appendChild(cosa);
    };
}
function RestartHistory(){ // Reinicia y vuelve a imprimir el historial de las canciones
    var histo = document.getElementById("history");
    var hist;
    histo.innerHTML= "";
    historial.forEach( e => {
        hist = document.createElement("li");
        hist.innerHTML = e;
        histo.appendChild(hist);
    });
}

function Agregar(){ // Agrega canciones que nosotros escribamos
    var nuevo = document.getElementById("agregar").value;
    if(nuevo){
        canciones.push(nuevo);
    }
    RestartQueue();
}

function Siguiente(){ // Se reproducira la cancion siguiente de la Queue
    var reproduccion = document.getElementById("reproduciendo");
    if(reproductor && canciones[0]){
        historial.push(reproductor)
    }
    if(canciones[0]){
        reproductor = canciones[0];
        reproduccion.innerHTML= ("En reproduccion: "+ reproductor);
        canciones.shift();
    }else{  // Si no hay canciones en la Queue no reproduce nada
        reproduccion.innerHTML= ("En reproduccion: ");
    }
    RestartQueue();
    RestartHistory();
}

function Atras(){ // Se reproducira la cancion anterior que esta en el historial
    var reproduccion = document.getElementById("reproduciendo");
    if(reproductor){
        canciones.splice(0,0,reproductor);
        reproductor = historial[historial.length-1];
        if(reproductor){
            reproduccion.innerHTML= ("En reproduccion: "+ reproductor );
        }else{ // Si ya no hay canciones anteriores no reproduce nada
            reproduccion.innerHTML= ("En reproduccion: ")
        }
       
    }
    historial.pop();
    RestartHistory();
    RestartQueue();
}

function Eliminar(i){ // Elimina la cancion de la Queue
    canciones.splice(i,1);
    RestartHistory();
    RestartQueue();
}