
class Node {
    constructor(value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }
}

class BinaryTree {
    constructor() {
        this.root = null;
    }

    insert(value) {
        const newNode = new Node(value);

        if (!this.root) {
            this.root = newNode;
            return this;
        }

        let currentNode = this.root;

        while (true) {
            if (value === currentNode.value) return undefined;

            if (value < currentNode.value) {
                if (!currentNode.left) {
                    currentNode.left = newNode;
                    return this;
                }
                currentNode = currentNode.left;
            } else {
                if (!currentNode.right) {
                    currentNode.right = newNode;
                    return this;
                }
                currentNode = currentNode.right;
            }
        }
    }

   

    delete(value) {
        if (!this.root) return false;

        let currentNode = this.root;
        let parentNode = null;
        let found = false;
        let hijosCount = 0;

        while (currentNode && !found) {
            if (value < currentNode.value) {
                parentNode = currentNode;
                currentNode = currentNode.left;
            } else if (value > currentNode.value) {
                parentNode = currentNode;
                currentNode = currentNode.right;
            } else {
                found = true;
            }
        }

        if (!found) return false;

        if (currentNode.left && currentNode.right) {
            let minRightNode = currentNode.right;
            let minRightParentNode = currentNode;

            while (minRightNode.left) {
                minRightParentNode = minRightNode;
                minRightNode = minRightNode.left;
            }

            currentNode.value = minRightNode.value;
            currentNode = minRightNode;
            parentNode = minRightParentNode;
        }

        if (currentNode.left || currentNode.right) {
            hijosCount = 1;
        }

        if (hijosCount === 0) {
            if (currentNode === this.root) {
                this.root = null;
            } else {
                if (currentNode.value < parentNode.value) {
                    parentNode.left = null;
                } else {
                    parentNode.right = null;
                }
            }
        }

        if (hijosCount === 1) {
            let childNode = null;

            if (currentNode.left) {
                childNode = currentNode.left;
            } else {
                childNode = currentNode.right;
            }

            if (currentNode === this.root) {
                this.root = childNode;
            } else {
                if (currentNode.value < parentNode.value) {
                    parentNode.left = childNode;
                } else {
                    parentNode.right = childNode;
                }
            }
        }

        return true;
    }
}

let bst = new BinaryTree();
bst.insert(15);
bst.insert(25);
bst.insert(10);
bst.insert(7);
bst.insert(22);
bst.insert(17);
bst.insert(13);
bst.insert(5);
bst.insert(9);
bst.insert(27);

console.log(bst);

console.log(bst.delete(10));

console.log(bst);